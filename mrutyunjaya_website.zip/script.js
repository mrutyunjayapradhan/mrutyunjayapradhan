// script.js
document.addEventListener('DOMContentLoaded', () => {
  const loader = document.getElementById('loader');
  setTimeout(() => loader.style.display = 'none', 1000);

  const toggle = document.getElementById('dark-mode-toggle');
  toggle.addEventListener('click', () => {
    document.body.classList.toggle('dark');
  });

  const phrases = ['Welcome to My Journey', 'Explorer | Storyteller | Creator'];
  let i = 0, j = 0, currentPhrase = [], isDeleting = false, isEnd = false;

  const typing = () => {
    const typingText = document.getElementById('typing-text');
    isEnd = false;
    typingText.innerHTML = currentPhrase.join('');

    if (i < phrases.length) {
      if (!isDeleting && j <= phrases[i].length) {
        currentPhrase.push(phrases[i][j]);
        j++;
        typingText.innerHTML = currentPhrase.join('');
      }

      if (isDeleting && j <= phrases[i].length) {
        currentPhrase.pop(phrases[i][j]);
        j--;
      }

      if (j === phrases[i].length) {
        isEnd = true;
        isDeleting = true;
      }

      if (isDeleting && j === 0) {
        currentPhrase = [];
        isDeleting = false;
        i++;
        if (i === phrases.length) i = 0;
      }
    }
    const speed = isEnd ? 1500 : isDeleting ? 50 : 100;
    setTimeout(typing, speed);
  };

  typing();

  document.getElementById('contact-form').addEventListener('submit', function (e) {
    e.preventDefault();
    alert('Thank you for reaching out! I will get back to you soon.');
    this.reset();
  });
});

function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}
